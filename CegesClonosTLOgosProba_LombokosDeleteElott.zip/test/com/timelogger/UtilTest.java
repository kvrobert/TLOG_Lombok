/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timelogger;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rkissvincze
 */
public class UtilTest {
    
    public UtilTest() {
    }

    /**
     * Test of roundToMultipleQuarterHour method, of class Util.
     */
    @Test
    public void testRoundToMultipleQuarterHour() {
    }

    /**
     * Test of isMultipleQuarterHour method, of class Util.
     */
    @Test
    public void testIsMultipleQuarterHour() {
    }

    /**
     * Test of isWeekDay method, of class Util.
     */
    @Test
    public void testIsWeekDay() {
    }

    /**
     * Test of isSeparatedTime method, of class Util.
     */
    @Test
    public void testIsSeparatedTime() {
    }
    
}
