/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timelogger;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rkissvincze
 */
public class TimeLoggerUITest {
    
    public TimeLoggerUITest() {
    }

    /**
     * Test of printMenu method, of class TimeLoggerUI.
     */
    @Test
    public void testPrintMenu() {
    }

    /**
     * Test of selectMenu method, of class TimeLoggerUI.
     */
    @Test
    public void testSelectMenu() {
    }

    /**
     * Test of addNewDay method, of class TimeLoggerUI.
     */
    @Test
    public void testAddNewDay() {
    }
    
}
