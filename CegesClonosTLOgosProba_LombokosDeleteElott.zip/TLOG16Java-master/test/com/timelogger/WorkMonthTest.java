/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timelogger;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rkissvincze
 */
public class WorkMonthTest {
    
    public WorkMonthTest() {
    }

    /**
     * Test of getDays method, of class WorkMonth.
     */
    @Test
    public void testGetDays() {
    }

    /**
     * Test of getDate method, of class WorkMonth.
     */
    @Test
    public void testGetDate() {
    }

    /**
     * Test of getSumPerMonth method, of class WorkMonth.
     */
    @Test
    public void testGetSumPerMonth() {
    }

    /**
     * Test of getRequiredMinPerMonth method, of class WorkMonth.
     */
    @Test
    public void testGetRequiredMinPerMonth() {
    }

    /**
     * Test of getExtraMinPerMonth method, of class WorkMonth.
     */
    @Test
    public void testGetExtraMinPerMonth() {
    }

    /**
     * Test of isNewDate method, of class WorkMonth.
     */
    @Test
    public void testIsNewDate() {
    }

    /**
     * Test of isSameMonth method, of class WorkMonth.
     */
    @Test
    public void testIsSameMonth() {
    }

    /**
     * Test of addWorkDay method, of class WorkMonth.
     */
    @Test
    public void testAddWorkDay_WorkDay_boolean() {
    }

    /**
     * Test of addWorkDay method, of class WorkMonth.
     */
    @Test
    public void testAddWorkDay_WorkDay() {
    }

    /**
     * Test of toString method, of class WorkMonth.
     */
    @Test
    public void testToString() {
    }
    
}
