/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timelogger;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rkissvincze
 */
public class TimeLoggerTest {
    
    public TimeLoggerTest() {
    }

    /**
     * Test of getMonths method, of class TimeLogger.
     */
    @Test
    public void testGetMonths() {
    }

    /**
     * Test of isNewMonth method, of class TimeLogger.
     */
    @Test
    public void testIsNewMonth() {
    }

    /**
     * Test of addMonth method, of class TimeLogger.
     */
    @Test
    public void testAddMonth() {
    }
    
}
